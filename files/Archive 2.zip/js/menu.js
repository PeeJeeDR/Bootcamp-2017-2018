var MenuState   = {
    create: function ()
    {

    },

    update: function () 
    {
        game.state.start( 'level_1' );
    }
}